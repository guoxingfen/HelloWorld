create
    definer = root@localhost procedure get_password(IN in_email varchar(255), OUT pwd varchar(255))
begin
    select password into pwd from users where email=in_email;
end;

